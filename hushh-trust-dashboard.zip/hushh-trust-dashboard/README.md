# Hushh · Trust Dashboard

A privacy control center built with React. Manage data permissions, categories, and trust scores across multiple user profiles.

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ and npm

### Install & Run

```bash
# 1. Unzip the project
unzip hushh-trust-dashboard.zip
cd hushh-trust-dashboard

# 2. Install dependencies
npm install

# 3. Start the dev server
npm start
```

The app will open at **http://localhost:3000**

---

## 📦 Build for Production

```bash
npm run build
```

Output goes to the `build/` folder — ready to deploy to any static host (Vercel, Netlify, GitHub Pages, etc.).

---

## 🗂 Project Structure

```
hushh-trust-dashboard/
├── public/
│   └── index.html              # HTML shell (loads Google Fonts)
├── src/
│   ├── index.js                # React entry point
│   ├── index.css               # All global styles (CSS variables, glass, animations)
│   ├── App.js                  # Root component + routing between Auth and Dashboard
│   ├── data/
│   │   └── defaultProfiles.js  # Seed data for 3 demo profiles
│   ├── contexts/
│   │   └── AppContext.js       # Global state (profiles, active user, theme, toasts, AI cache)
│   └── components/
│       ├── AuthScreen.js       # Login screen (profile select, password, new profile)
│       ├── Header.js           # Sticky header, profile switcher, theme toggle
│       ├── ScoreBand.js        # Animated trust score ring + badges
│       ├── StatsRow.js         # 4-column stat cards
│       ├── PermissionsCard.js  # Service permissions with toggle + AI summary + revoke modal
│       ├── DataCategoriesCard.js # Category chips + exposure bar chart
│       ├── TrustCards.js       # Trust indicators grid + Audit log
│       ├── Sidebar.js          # Slide-in panel for adding permissions/categories/profiles
│       └── Toast.js            # Bottom toast notifications
└── package.json
```

---

## 🔑 Demo Credentials

| Profile   | Password    | Score |
|-----------|-------------|-------|
| Manish S. | manish123   | 94    |
| Priya K.  | priya123    | 78    |
| Arjun R.  | arjun123    | 88    |

> Passwords are shown on the login screen for demo convenience.

---

## ✨ Features

- **Multi-profile auth** — select a profile, enter password to log in or switch
- **Trust Score** — live-recalculates based on active permissions & sharing categories
- **Permissions management** — toggle on/off, revoke/restore, add new services
- **Data Categories** — toggle sharing chips, visualize exposure with animated bars
- **AI Trust Summaries** — click any permission row to fetch a plain-English summary via Claude API
- **Audit Log** — timestamped trail of every action
- **Dark / Light mode** — persistent via localStorage
- **Sidebar forms** — add permissions, categories, or new profiles
- **localStorage persistence** — all changes survive page refresh

---

## 🤖 AI Summaries (Claude API)

Permission row AI summaries call the Anthropic API directly from the browser.  
For local development this works out of the box since the `/v1/messages` endpoint is open to the browser when running through Claude.ai's artifact environment.

If deploying standalone, add your API key via a backend proxy and update the `fetch` call in `AppContext.js → getAiSummary()`.

---

## 🛠 Tech Stack

| Layer      | Choice                     |
|------------|----------------------------|
| Framework  | React 18                   |
| Styling    | Pure CSS (no CSS framework)|
| State      | React Context + useState   |
| Persistence| localStorage               |
| AI         | Anthropic Claude API       |
| Fonts      | Sora + JetBrains Mono      |
