import React from 'react';
import { useApp } from '../contexts/AppContext';

export default function DataCategoriesCard({ onOpenSidebar }) {
  const { getProfile, updateActiveProfile, recalcScore } = useApp();
  const p = getProfile();
  if (!p) return null;

  const cats = Object.entries(p.cats);
  const activeCount = cats.filter(([, v]) => v.on).length;
  const onCats = cats.filter(([, v]) => v.on);

  function toggleCat(key) {
    updateActiveProfile(prof => ({
      ...prof,
      cats: { ...prof.cats, [key]: { ...prof.cats[key], on: !prof.cats[key].on } },
    }));
    recalcScore();
  }

  return (
    <div className="card glass">
      <div className="card-head">
        <div className="card-title">Data Categories</div>
        <div className="card-head-actions">
          <div className="card-badge">{activeCount} sharing</div>
          <button className="add-btn" onClick={() => onOpenSidebar('category')}>＋ Add</button>
        </div>
      </div>
      <div className="cat-grid">
        {cats.map(([key, v]) => (
          <div key={key} className={`chip${v.on ? ' on' : ''}`} onClick={() => toggleCat(key)}>
            <span className="chip-ico">{v.ico}</span>
            <span className="chip-name">{v.label}</span>
            <span className="chip-dot" />
          </div>
        ))}
      </div>
      <div className="bars-section">
        <div className="bar-inner">
          <div className="bar-section-title">Data Exposure Overview</div>
          {onCats.length === 0 ? (
            <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 500 }}>No categories currently sharing</span>
          ) : (
            onCats.map(([, v]) => (
              <div key={v.label} className="bar-row">
                <span className="bar-ico">{v.ico}</span>
                <span className="bar-label">{v.label}</span>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: v.pct + '%' }} />
                </div>
                <span className="bar-pct">{v.pct}%</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
