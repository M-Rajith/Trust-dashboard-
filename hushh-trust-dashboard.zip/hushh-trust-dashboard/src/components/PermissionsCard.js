import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';

export default function PermissionsCard({ onOpenSidebar }) {
  const { getProfile, updateActiveProfile, addLog, recalcScore, showToast } = useApp();
  const [openAI, setOpenAI] = useState(null);
  const [aiTexts, setAiTexts] = useState({});
  const [aiLoading, setAiLoading] = useState({});
  const [revokeModal, setRevokeModal] = useState(null);
  const { getAiSummary } = useApp();

  const p = getProfile();
  if (!p) return null;

  const svcs = Object.values(p.svcs);
  const activeCount = svcs.filter(s => s.on).length;

  async function handleRowClick(svcId) {
    if (openAI === svcId) { setOpenAI(null); return; }
    setOpenAI(svcId);
    if (!aiTexts[svcId]) {
      setAiLoading(l => ({ ...l, [svcId]: true }));
      const text = await getAiSummary(svcId);
      setAiTexts(t => ({ ...t, [svcId]: text }));
      setAiLoading(l => ({ ...l, [svcId]: false }));
    }
  }

  function openRevoke(e, svc) {
    e.stopPropagation();
    setRevokeModal(svc);
  }

  function execRevoke() {
    const svc = revokeModal;
    const was = svc.on;
    updateActiveProfile(p => {
      const next = { ...p, svcs: { ...p.svcs, [svc.id]: { ...p.svcs[svc.id], on: !was } }, consentCount: p.consentCount + 1 };
      return next;
    });
    addLog(was ? `You revoked ${svc.name} access` : `You restored ${svc.name} access`, was ? 'rev' : 'new', was ? '🚫' : '✅');
    recalcScore();
    showToast('✓ ' + (was ? `${svc.name} access revoked` : `${svc.name} access restored`));
    setRevokeModal(null);
  }

  return (
    <>
      <div className="card glass">
        <div className="card-head">
          <div className="card-title">Active Permissions</div>
          <div className="card-head-actions">
            <div className="card-badge">{activeCount} active</div>
            <button className="add-btn" onClick={() => onOpenSidebar('permission')}>＋ Add</button>
          </div>
        </div>
        {svcs.length === 0 ? (
          <div style={{ padding: '20px 22px', fontSize: 13, color: 'var(--muted)' }}>No permissions yet. Add one with + Add.</div>
        ) : (
          svcs.map(svc => (
            <React.Fragment key={svc.id}>
              <div className="prow" onClick={() => handleRowClick(svc.id)}>
                <div className="sicon" style={{ background: svc.bg }}>{svc.emoji}</div>
                <div className="sinfo">
                  <div className="sname">{svc.name}</div>
                  <div className="sscope">{svc.scope}</div>
                </div>
                <div className="sright">
                  <div className="saccess">{svc.ago}</div>
                  <button
                    className={`tog${svc.on ? ' on' : ''}`}
                    onClick={e => openRevoke(e, svc)}
                  />
                </div>
              </div>
              <div className={`ai-panel${openAI === svc.id ? ' open' : ''}`}>
                <div className="ai-inner">
                  <div className="ai-lbl">🤖 AI Trust Summary</div>
                  <div className="ai-txt">
                    {aiLoading[svc.id]
                      ? <><span className="spin" />Generating…</>
                      : aiTexts[svc.id] || 'Click row to generate…'}
                  </div>
                </div>
              </div>
            </React.Fragment>
          ))
        )}
      </div>

      {/* Revoke Modal */}
      {revokeModal && (
        <div className="overlay vis" onClick={e => { if (e.target === e.currentTarget) setRevokeModal(null); }}>
          <div className="modal">
            <div className="modal-head">
              <div className="modal-ico" style={{
                background: revokeModal.on ? 'rgba(255,69,58,0.12)' : 'rgba(48,209,88,0.12)',
                border: `1px solid ${revokeModal.on ? 'rgba(255,69,58,0.18)' : 'rgba(48,209,88,0.18)'}`,
              }}>
                {revokeModal.on ? '🚫' : '✅'}
              </div>
              <div className="modal-title">{revokeModal.on ? 'Revoke Access?' : 'Restore Access?'}</div>
            </div>
            <div className="modal-body">
              {revokeModal.on
                ? 'This will immediately stop all data sharing with this service. The action is logged and timestamped in your audit trail.'
                : 'This will restore data sharing with this service. The action is logged and timestamped.'}
            </div>
            <div className="modal-svc">
              <div className="modal-sname">{revokeModal.name}</div>
              <div className="modal-scope">{revokeModal.scope}</div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-cancel" onClick={() => setRevokeModal(null)}>Cancel</button>
              <button className="btn btn-confirm" style={{
                background: revokeModal.on ? 'var(--red)' : 'var(--blue)',
                boxShadow: revokeModal.on ? '0 4px 16px rgba(255,69,58,0.35)' : '0 4px 16px rgba(0,113,227,0.35)',
              }} onClick={execRevoke}>
                {revokeModal.on ? 'Revoke Access' : 'Restore Access'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
