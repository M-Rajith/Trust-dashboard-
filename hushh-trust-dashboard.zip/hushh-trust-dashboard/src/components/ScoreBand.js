import React from 'react';
import { useApp } from '../contexts/AppContext';

export default function ScoreBand() {
  const { getProfile, scoreLabel, scoreOffset } = useApp();
  const p = getProfile();
  if (!p) return null;

  const on   = Object.values(p.svcs).filter(s => s.on).length;
  const cats = Object.values(p.cats).filter(c => c.on).length;
  const desc = `${p.name} has ${on} active permission${on !== 1 ? 's' : ''} and ${cats} data categor${cats !== 1 ? 'ies' : 'y'} sharing. Score: ${p.score}/100.`;
  const strokeColor = p.score >= 80 ? 'var(--blue)' : p.score >= 60 ? 'var(--amber)' : 'var(--red)';

  return (
    <div className="score-band">
      <div className="score-ring">
        <svg viewBox="0 0 86 86" width="86" height="86">
          <circle className="track" cx="43" cy="43" r="39" />
          <circle
            className="fill"
            cx="43" cy="43" r="39"
            style={{ strokeDashoffset: scoreOffset(p.score), stroke: strokeColor }}
          />
        </svg>
        <div className="score-num" style={{ color: strokeColor }}>{p.score}</div>
      </div>
      <div>
        <div className="score-title">{scoreLabel(p.score)}</div>
        <div className="score-desc">{desc}</div>
        <div className="score-badges">
          <div className="sbadge"><span className="sbadge-dot" style={{ background: 'var(--green)' }} />SOC 2 Certified</div>
          <div className="sbadge"><span className="sbadge-dot" style={{ background: 'var(--blue)' }} />GDPR Compliant</div>
          <div className="sbadge"><span className="sbadge-dot" style={{ background: 'var(--cyan)' }} />DPDP Act Ready</div>
          <div className="sbadge"><span className="sbadge-dot" style={{ background: 'var(--purple)' }} />On-Device Vault</div>
        </div>
      </div>
    </div>
  );
}
