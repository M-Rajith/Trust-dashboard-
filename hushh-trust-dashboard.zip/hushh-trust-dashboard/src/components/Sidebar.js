import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';

const SERVICE_EMOJIS = ['🔗','📱','🎮','🛒','🏦','📧','🎵','📚','🏥','✈️','🏠','💼','📸','📦','🎬','🔍','💬','⌚'];
const CAT_EMOJIS     = ['📁','🛍️','💳','🌐','💊','📍','🪪','📱','🏠','🎵','📚','🏋️','✈️','🎮','💰','🤝'];
const PROFILE_EMOJIS = ['👨‍💻','👩‍🎨','👨‍⚕️','👩‍💼','👨‍🔬','👩‍🏫','🧑‍🎤','👴','👩‍🚀','🧑‍🍳'];
const BG_COLORS = [
  ['rgba(255,248,220,0.7)','#f0b900'],
  ['rgba(220,255,235,0.7)','#30d158'],
  ['rgba(225,235,255,0.7)','#0071e3'],
  ['rgba(255,235,233,0.7)','#ff453a'],
  ['rgba(230,220,255,0.7)','#bf5af2'],
  ['rgba(220,248,255,0.7)','#32ade6'],
];
const PROFILE_COLORS = [
  'linear-gradient(135deg,#0071e3,#004eb8)',
  'linear-gradient(135deg,#bf5af2,#7b2dcc)',
  'linear-gradient(135deg,#30d158,#1a7a35)',
  'linear-gradient(135deg,#ff9f0a,#c97800)',
  'linear-gradient(135deg,#ff453a,#c0392b)',
  'linear-gradient(135deg,#32ade6,#1a6fa0)',
];

export default function Sidebar({ mode, onClose }) {
  const { updateActiveProfile, updateProfiles, addLog, recalcScore, showToast } = useApp();

  // Permission form
  const [svcEmoji, setSvcEmoji] = useState('🔗');
  const [svcName, setSvcName]   = useState('');
  const [svcScope, setSvcScope] = useState('');
  const [svcBg, setSvcBg]       = useState(BG_COLORS[2][0]);
  const [svcStatus, setSvcStatus] = useState('on');

  // Category form
  const [catEmoji, setCatEmoji] = useState('📁');
  const [catName, setCatName]   = useState('');
  const [catStatus, setCatStatus] = useState('on');
  const [catPct, setCatPct]     = useState(50);

  // Profile form
  const [pEmoji, setPEmoji]   = useState('👨‍💻');
  const [pColor, setPColor]   = useState(PROFILE_COLORS[0]);
  const [pName, setPName]     = useState('');
  const [pPw, setPPw]         = useState('');
  const [pPwVis, setPPwVis]   = useState(false);
  const [pScore, setPScore]   = useState(75);

  const titles = { permission: 'Add Permission', category: 'Add Data Category', profile: 'Add New Profile' };

  function submitPermission() {
    if (!svcName.trim()) { showToast('⚠️ Enter a service name'); return; }
    if (!svcScope.trim()) { showToast('⚠️ Describe the data scope'); return; }
    const id = 'svc_' + Date.now();
    updateActiveProfile(p => ({
      ...p,
      svcs: { ...p.svcs, [id]: { id, name: svcName.trim(), emoji: svcEmoji, bg: svcBg, scope: svcScope.trim(), on: svcStatus === 'on', ago: 'Just now' } },
      consentCount: p.consentCount + 1,
    }));
    recalcScore();
    addLog(`You added ${svcName.trim()} permission`, 'new', '✅');
    showToast(`✓ ${svcName.trim()} added`);
    onClose();
  }

  function submitCategory() {
    if (!catName.trim()) { showToast('⚠️ Enter a category name'); return; }
    const id = 'cat_' + Date.now();
    updateActiveProfile(p => ({
      ...p,
      cats: { ...p.cats, [id]: { label: catName.trim(), ico: catEmoji, on: catStatus === 'on', pct: catStatus === 'on' ? catPct : 0 } },
    }));
    recalcScore();
    addLog(`You added ${catName.trim()} data category`, 'new', '✅');
    showToast(`✓ ${catName.trim()} added`);
    onClose();
  }

  function submitProfile() {
    if (!pName.trim()) { showToast('⚠️ Enter a name'); return; }
    if (!pPw || pPw.length < 4) { showToast('⚠️ Password must be 4+ chars'); return; }
    const id = 'user_' + Date.now();
    updateProfiles(prev => ({
      ...prev,
      [id]: {
        id, name: pName.trim(), emoji: pEmoji, color: pColor,
        password: pPw, score: pScore, consentCount: 0,
        svcs: {},
        cats: {
          shopping: { label: 'Shopping', ico: '🛍️', on: false, pct: 0 },
          browsing: { label: 'Browsing', ico: '🌐', on: false, pct: 0 },
        },
        logs: [{ action: `Profile ${pName.trim()} created`, type: 'new', icon: '✅', time: 'Just now' }],
      },
    }));
    showToast(`✓ Profile "${pName.trim()}" created — switch via profile menu`);
    onClose();
  }

  return (
    <>
      <div className="sidebar-overlay open" onClick={onClose} />
      <div className="sidebar glass open">
        <div className="sidebar-inner">
          <div className="sidebar-head">
            <div className="sidebar-title">{titles[mode]}</div>
            <button className="sidebar-close" onClick={onClose}>✕</button>
          </div>

          {/* ── PERMISSION FORM ── */}
          {mode === 'permission' && (
            <>
              <div className="sb-section">Service Icon</div>
              <div className="emoji-options">
                {SERVICE_EMOJIS.map(e => (
                  <div key={e} className={`emoji-opt${svcEmoji === e ? ' picked' : ''}`} onClick={() => setSvcEmoji(e)}>{e}</div>
                ))}
              </div>
              <div className="sb-section" style={{ marginTop: 18 }}>Service Details</div>
              <div className="form-group">
                <label className="form-label">Service Name</label>
                <input className="form-input" placeholder="e.g. LinkedIn" value={svcName} onChange={e => setSvcName(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Data Scope</label>
                <input className="form-input" placeholder="e.g. Profile data, connections" value={svcScope} onChange={e => setSvcScope(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Icon Background</label>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {BG_COLORS.map(([bg, border]) => (
                    <div
                      key={bg}
                      onClick={() => setSvcBg(bg)}
                      style={{
                        width: 26, height: 26, borderRadius: '50%', background: bg,
                        border: `2px solid ${border}`, cursor: 'pointer',
                        transform: svcBg === bg ? 'scale(1.25)' : 'scale(1)',
                        transition: 'transform .16s',
                      }}
                    />
                  ))}
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-select" value={svcStatus} onChange={e => setSvcStatus(e.target.value)}>
                  <option value="on">Active</option>
                  <option value="off">Paused</option>
                </select>
              </div>
              <button className="submit-btn" onClick={submitPermission}>Add Permission →</button>
            </>
          )}

          {/* ── CATEGORY FORM ── */}
          {mode === 'category' && (
            <>
              <div className="sb-section">Category Icon</div>
              <div className="emoji-options">
                {CAT_EMOJIS.map(e => (
                  <div key={e} className={`emoji-opt${catEmoji === e ? ' picked' : ''}`} onClick={() => setCatEmoji(e)}>{e}</div>
                ))}
              </div>
              <div className="sb-section" style={{ marginTop: 18 }}>Category Details</div>
              <div className="form-group">
                <label className="form-label">Category Name</label>
                <input className="form-input" placeholder="e.g. Travel" value={catName} onChange={e => setCatName(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Sharing Status</label>
                <select className="form-select" value={catStatus} onChange={e => setCatStatus(e.target.value)}>
                  <option value="on">Sharing</option>
                  <option value="off">Not Sharing</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Exposure Level: <span style={{ color: 'var(--blue)' }}>{catPct}%</span></label>
                <input type="range" className="pct-slider" min="0" max="100" value={catPct} onChange={e => setCatPct(+e.target.value)} />
              </div>
              <button className="submit-btn" onClick={submitCategory}>Add Category →</button>
            </>
          )}

          {/* ── PROFILE FORM ── */}
          {mode === 'profile' && (
            <>
              <div className="sb-section">Avatar</div>
              <div className="emoji-options">
                {PROFILE_EMOJIS.map(e => (
                  <div key={e} className={`emoji-opt${pEmoji === e ? ' picked' : ''}`} onClick={() => setPEmoji(e)}>{e}</div>
                ))}
              </div>
              <div className="sb-section" style={{ marginTop: 18 }}>Profile Color</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
                {PROFILE_COLORS.map((g, i) => (
                  <div key={i} onClick={() => setPColor(g)} style={{
                    width: 26, height: 26, borderRadius: '50%', background: g, cursor: 'pointer',
                    border: pColor === g ? '3px solid white' : '2px solid transparent',
                    boxShadow: pColor === g ? '0 0 0 2px #0071e3' : 'none',
                    transform: pColor === g ? 'scale(1.2)' : 'scale(1)',
                    transition: 'transform .16s',
                  }} />
                ))}
              </div>
              <div className="sb-section">Profile Details</div>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input className="form-input" placeholder="e.g. Rahul M." value={pName} onChange={e => setPName(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <div style={{ position: 'relative' }}>
                  <input className="form-input" type={pPwVis ? 'text' : 'password'} placeholder="Set a password" value={pPw} onChange={e => setPPw(e.target.value)} style={{ paddingRight: 40 }} />
                  <button className="auth-eye" style={{ top: '50%' }} onClick={() => setPPwVis(v => !v)} tabIndex={-1}>👁</button>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Starting Trust Score: <span style={{ color: 'var(--blue)' }}>{pScore}/100</span></label>
                <input type="range" className="pct-slider" min="30" max="100" value={pScore} onChange={e => setPScore(+e.target.value)} />
              </div>
              <button className="submit-btn" onClick={submitProfile}>Create Profile →</button>
            </>
          )}
        </div>
      </div>
    </>
  );
}
