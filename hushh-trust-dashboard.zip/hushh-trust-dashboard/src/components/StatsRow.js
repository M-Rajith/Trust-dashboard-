import React from 'react';
import { useApp } from '../contexts/AppContext';

export default function StatsRow() {
  const { getProfile } = useApp();
  const p = getProfile();
  if (!p) return null;

  const svcsOn = Object.values(p.svcs).filter(s => s.on).length;
  const svcsT  = Object.keys(p.svcs).length;
  const catsOn = Object.values(p.cats).filter(c => c.on).length;
  const catsT  = Object.keys(p.cats).length;

  return (
    <div className="stats">
      <div className="stat-card glass">
        <div className="sc-icon" style={{ background: 'rgba(0,113,227,0.10)', border: '1px solid rgba(0,113,227,0.14)' }}>🔗</div>
        <div className="sc-lbl">Active Permissions</div>
        <div className="sc-val" style={{ color: 'var(--blue)' }}>{svcsOn}</div>
        <div className="sc-meta">of {svcsT} services</div>
      </div>
      <div className="stat-card glass">
        <div className="sc-icon" style={{ background: 'rgba(191,90,242,0.10)', border: '1px solid rgba(191,90,242,0.14)' }}>📋</div>
        <div className="sc-lbl">Consent Receipts</div>
        <div className="sc-val" style={{ color: 'var(--purple)' }}>{p.consentCount}</div>
        <div className="sc-meta">signed &amp; timestamped</div>
      </div>
      <div className="stat-card glass">
        <div className="sc-icon" style={{ background: 'rgba(255,159,10,0.10)', border: '1px solid rgba(255,159,10,0.14)' }}>📂</div>
        <div className="sc-lbl">Data Categories</div>
        <div className="sc-val" style={{ color: 'var(--amber)' }}>{catsOn}</div>
        <div className="sc-meta">of {catsT} sharing</div>
      </div>
      <div className="stat-card glass">
        <div className="sc-icon" style={{ background: 'rgba(48,209,88,0.10)', border: '1px solid rgba(48,209,88,0.14)' }}>✅</div>
        <div className="sc-lbl">Last Audit</div>
        <div className="sc-val" style={{ color: 'var(--green)', fontSize: 20, paddingTop: 6 }}>Mar 24</div>
        <div className="sc-meta">Passed all checks</div>
      </div>
    </div>
  );
}
