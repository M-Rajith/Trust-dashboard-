import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';

export default function Header({ onLogout, onOpenSidebar }) {
  const { profiles, activeId, getProfile, darkMode, setDarkMode } = useApp();
  const [ddOpen, setDdOpen] = useState(false);
  const [switchModal, setSwitchModal] = useState(null); // profile id pending switch
  const [swPw, setSwPw] = useState('');
  const [swPwVis, setSwPwVis] = useState(false);
  const [swError, setSwError] = useState('');
  const { setActiveId, showToast, updateProfiles } = useApp();
  const ddRef = useRef(null);
  const swInputRef = useRef(null);

  const p = getProfile();

  useEffect(() => {
    function handleClick(e) {
      if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
    }
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  function requestSwitch(id) {
    if (id === activeId) { setDdOpen(false); return; }
    setDdOpen(false);
    setSwitchModal(id);
    setSwPw(''); setSwError(''); setSwPwVis(false);
    setTimeout(() => swInputRef.current?.focus(), 100);
  }

  function execSwitch() {
    const target = profiles[switchModal];
    if (!swPw) { setSwError('Please enter the password.'); return; }
    if (swPw !== target.password) { setSwError('Incorrect password. Try again.'); setSwPw(''); return; }
    setSwError('');
    setSwitchModal(null);
    setActiveId(switchModal);
    showToast('✓ Switched to ' + target.name);
  }

  return (
    <>
      <header>
        <div className="logo">
          <div className="logo-mark">🔒</div>
          hushh
        </div>
        <div className="nav-right">
          <div className="npill active">
            <span className="live-dot" />
            <span id="score-pill">Trust {p?.score}/100</span>
          </div>
          <div className="npill">🔒 On-Device Vault</div>

          {/* Profile pill */}
          <div className="profile-pill" onClick={e => { e.stopPropagation(); setDdOpen(o => !o); }} ref={ddRef}>
            <div className="profile-avatar" style={{ background: p?.color }}>{p?.emoji}</div>
            <div>
              <div className="profile-pname">{p?.name}</div>
              <div className="profile-pscore">{p?.score} / 100</div>
            </div>
            <span className="chevron">▾</span>

            <div className={`profile-dropdown glass${ddOpen ? ' open' : ''}`} onClick={e => e.stopPropagation()}>
              <div className="pd-header">
                <div className="pd-header-title">Switch Profile</div>
                <div className="pd-header-sub">Password required to switch</div>
              </div>
              <div className="pd-profiles">
                {Object.values(profiles).map(prof => (
                  <div key={prof.id} className={`pd-item${prof.id === activeId ? ' current' : ''}`} onClick={() => requestSwitch(prof.id)}>
                    <div className="pd-av" style={{ background: prof.color }}>{prof.emoji}</div>
                    <div className="pd-info">
                      <div className="pd-iname">{prof.name}</div>
                      <div className="pd-iscore">Trust: {prof.score}/100</div>
                    </div>
                    {prof.id === activeId ? <span className="pd-check">✓</span> : <span className="pd-lock">🔒</span>}
                  </div>
                ))}
              </div>
              <div className="pd-actions">
                <button className="pd-action-btn pd-btn-add" onClick={() => { onOpenSidebar('profile'); setDdOpen(false); }}>＋ Add New Profile</button>
                <button className="pd-action-btn pd-btn-logout" onClick={onLogout}>⏻ Sign Out</button>
              </div>
            </div>
          </div>

          {/* Theme toggle */}
          <div className="theme-wrap" onClick={() => setDarkMode(d => !d)}>
            <span className="theme-lbl">{darkMode ? '🌙' : '☀️'}</span>
            <div className="theme-track"><div className="theme-thumb">🌙</div></div>
          </div>
        </div>
      </header>

      {/* Switch Password Modal */}
      {switchModal && (
        <div className="overlay vis" onClick={e => { if (e.target === e.currentTarget) setSwitchModal(null); }}>
          <div className="modal">
            <div className="modal-head">
              <div className="modal-ico" style={{ background: 'rgba(0,113,227,0.12)', border: '1px solid rgba(0,113,227,0.18)', fontSize: 22 }}>
                {profiles[switchModal]?.emoji}
              </div>
              <div className="modal-title">Switch to {profiles[switchModal]?.name}</div>
            </div>
            <div className="modal-body">Enter {profiles[switchModal]?.name}'s password to switch profiles.</div>
            <div className="auth-form-group" style={{ marginBottom: 20 }}>
              <label className="auth-label">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  ref={swInputRef}
                  className={`auth-input${swError ? ' error' : ''}`}
                  type={swPwVis ? 'text' : 'password'}
                  placeholder="Enter profile password"
                  value={swPw}
                  onChange={e => { setSwPw(e.target.value); setSwError(''); }}
                  onKeyDown={e => e.key === 'Enter' && execSwitch()}
                />
                <button className="auth-eye" onClick={() => setSwPwVis(v => !v)} tabIndex={-1}>👁</button>
              </div>
              <div className={`auth-error${swError ? ' show' : ''}`}>{swError}</div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-cancel" onClick={() => setSwitchModal(null)}>Cancel</button>
              <button className="btn btn-confirm" style={{ background: 'var(--blue)', boxShadow: '0 4px 16px rgba(0,113,227,0.35)' }} onClick={execSwitch}>
                Switch Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
