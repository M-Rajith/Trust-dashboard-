import React, { useState, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import DEFAULT_PROFILES from '../data/defaultProfiles';

const AVATAR_EMOJIS = ['👨‍💻','👩‍🎨','👨‍⚕️','👩‍💼','👨‍🔬','👩‍🏫','🧑‍🎤','👴','👩‍🚀','🧑‍🍳'];
const AVATAR_COLORS = [
  'linear-gradient(135deg,#0071e3,#004eb8)',
  'linear-gradient(135deg,#bf5af2,#7b2dcc)',
  'linear-gradient(135deg,#30d158,#1a7a35)',
  'linear-gradient(135deg,#ff9f0a,#c97800)',
  'linear-gradient(135deg,#ff453a,#c0392b)',
  'linear-gradient(135deg,#32ade6,#1a6fa0)',
];

export default function AuthScreen({ onLogin }) {
  const { profiles, updateProfiles, showToast } = useApp();
  const [step, setStep] = useState('select'); // 'select' | 'password' | 'new'
  const [selectedId, setSelectedId] = useState(null);
  const [pw, setPw] = useState('');
  const [pwVisible, setPwVisible] = useState(false);
  const [pwError, setPwError] = useState('');
  // New profile form
  const [npName, setNpName] = useState('');
  const [npPw, setNpPw] = useState('');
  const [npPwVis, setNpPwVis] = useState(false);
  const [npEmoji, setNpEmoji] = useState('👨‍💻');
  const [npColor, setNpColor] = useState(AVATAR_COLORS[0]);
  const pwInputRef = useRef(null);

  const selectedProfile = selectedId ? profiles[selectedId] : null;

  function selectProfile(id) {
    setSelectedId(id);
  }

  function goToPassword() {
    if (!selectedId) return;
    setPw(''); setPwError(''); setPwVisible(false);
    setStep('password');
    setTimeout(() => pwInputRef.current?.focus(), 100);
  }

  function doLogin() {
    if (!pw) { setPwError('Please enter your password.'); return; }
    if (pw !== selectedProfile.password) {
      setPwError('Incorrect password. Try again.');
      setPw('');
      return;
    }
    setPwError('');
    onLogin(selectedId);
  }

  function createNewProfile() {
    if (!npName.trim()) { showToast('⚠️ Enter a display name'); return; }
    if (!npPw || npPw.length < 4) { showToast('⚠️ Password must be at least 4 characters'); return; }
    const id = 'user_' + Date.now();
    updateProfiles(prev => ({
      ...prev,
      [id]: {
        id, name: npName.trim(), emoji: npEmoji, color: npColor,
        password: npPw, score: 75, consentCount: 0,
        svcs: {},
        cats: {
          shopping: { label: 'Shopping', ico: '🛍️', on: false, pct: 0 },
          browsing: { label: 'Browsing', ico: '🌐', on: false, pct: 0 },
          finance:  { label: 'Finance',  ico: '💳', on: false, pct: 0 },
        },
        logs: [{ action: `Profile ${npName.trim()} created`, type: 'new', icon: '✅', time: 'Just now' }],
      },
    }));
    setStep('select');
    setSelectedId(null);
    showToast('✓ Profile created — select it to sign in');
  }

  return (
    <div className="auth-screen">
      <div className="bg-canvas">
        <div className="orb orb1" /><div className="orb orb2" /><div className="orb orb3" />
      </div>
      <div className="grain" />

      <div className="auth-card glass" style={{ position: 'relative', zIndex: 2 }}>
        <div className="auth-logo">
          <div className="auth-logo-mark">🔒</div>
          <div className="auth-logo-text">hushh</div>
        </div>

        {/* ── STEP: SELECT ── */}
        {step === 'select' && (
          <>
            <div className="auth-title">Welcome back</div>
            <div className="auth-sub">Select your profile to continue</div>
            <div className="profile-select-grid">
              {Object.values(profiles).map(p => (
                <div
                  key={p.id}
                  className={`profile-select-tile${selectedId === p.id ? ' selected' : ''}`}
                  onClick={() => selectProfile(p.id)}
                >
                  <div className="pst-avatar" style={{ background: p.color }}>{p.emoji}</div>
                  <div className="pst-name">{p.name}</div>
                  <div className="pst-score">{p.score}/100</div>
                  <div className="pst-hint">pw: {p.password}</div>
                </div>
              ))}
            </div>
            <button className="auth-btn" disabled={!selectedId} onClick={goToPassword}>
              Continue →
            </button>
            <button
              style={{ background: 'none', border: 'none', width: '100%', marginTop: 12, cursor: 'pointer', color: 'var(--blue)', fontFamily: 'var(--sans)', fontSize: 13, fontWeight: 700 }}
              onClick={() => { setStep('new'); setNpName(''); setNpPw(''); setNpEmoji('👨‍💻'); setNpColor(AVATAR_COLORS[0]); }}
            >
              + Create new profile
            </button>
            <div className="auth-hint">Your data never leaves this device without consent</div>
          </>
        )}

        {/* ── STEP: PASSWORD ── */}
        {step === 'password' && selectedProfile && (
          <>
            <button className="auth-back" onClick={() => setStep('select')}>← Back</button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 22 }}>
              <div style={{ width: 48, height: 48, borderRadius: '50%', background: selectedProfile.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>
                {selectedProfile.emoji}
              </div>
              <div>
                <div style={{ fontSize: 18, fontWeight: 900, letterSpacing: '-0.5px' }}>Welcome back, {selectedProfile.name.split(' ')[0]}</div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)' }}>{selectedProfile.name}</div>
              </div>
            </div>
            <div className="auth-form-group">
              <label className="auth-label">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  ref={pwInputRef}
                  className={`auth-input${pwError ? ' error' : ''}`}
                  type={pwVisible ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={pw}
                  onChange={e => { setPw(e.target.value); setPwError(''); }}
                  onKeyDown={e => e.key === 'Enter' && doLogin()}
                />
                <button className="auth-eye" onClick={() => setPwVisible(v => !v)} tabIndex={-1}>👁</button>
              </div>
              <div className={`auth-error${pwError ? ' show' : ''}`}>{pwError}</div>
            </div>
            <button className="auth-btn" onClick={doLogin}>Sign In →</button>
            <div className="auth-hint">Protected with on-device encryption</div>
          </>
        )}

        {/* ── STEP: NEW PROFILE ── */}
        {step === 'new' && (
          <>
            <button className="auth-back" onClick={() => setStep('select')}>← Back</button>
            <div className="auth-title" style={{ marginBottom: 20 }}>Create Profile</div>

            <div className="sb-section" style={{ marginTop: 0 }}>Choose Avatar</div>
            <div className="emoji-options" style={{ marginBottom: 16 }}>
              {AVATAR_EMOJIS.map(e => (
                <div key={e} className={`emoji-opt${npEmoji === e ? ' picked' : ''}`} onClick={() => setNpEmoji(e)}>{e}</div>
              ))}
            </div>

            <div className="sb-section">Profile Color</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
              {AVATAR_COLORS.map((g, i) => (
                <div
                  key={i}
                  onClick={() => setNpColor(g)}
                  style={{
                    width: 26, height: 26, borderRadius: '50%', background: g,
                    cursor: 'pointer', transition: 'transform .16s',
                    border: npColor === g ? '3px solid white' : '2px solid transparent',
                    boxShadow: npColor === g ? '0 0 0 2px #0071e3' : 'none',
                    transform: npColor === g ? 'scale(1.2)' : 'scale(1)',
                  }}
                />
              ))}
            </div>

            <div className="auth-form-group">
              <label className="auth-label">Display Name</label>
              <input
                className="auth-input"
                placeholder="e.g. Rahul M."
                value={npName}
                onChange={e => setNpName(e.target.value)}
              />
            </div>
            <div className="auth-form-group">
              <label className="auth-label">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  className="auth-input"
                  type={npPwVis ? 'text' : 'password'}
                  placeholder="Min 4 characters"
                  value={npPw}
                  onChange={e => setNpPw(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && createNewProfile()}
                />
                <button className="auth-eye" onClick={() => setNpPwVis(v => !v)} tabIndex={-1}>👁</button>
              </div>
            </div>
            <button className="auth-btn" onClick={createNewProfile}>Create Profile →</button>
          </>
        )}
      </div>
    </div>
  );
}
