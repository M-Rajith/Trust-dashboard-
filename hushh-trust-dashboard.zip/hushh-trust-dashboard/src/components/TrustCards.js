import React from 'react';
import { useApp } from '../contexts/AppContext';

export function TrustIndicatorsCard() {
  return (
    <div className="card glass">
      <div className="card-head">
        <div className="card-title">Trust Indicators</div>
        <div className="card-badge">All Verified ✓</div>
      </div>
      <div className="trust-grid">
        {[
          { ico: '🛡️', name: 'SOC 2',     sub: 'Type II certified' },
          { ico: '🇪🇺', name: 'GDPR',      sub: 'Compliant' },
          { ico: '🔒', name: 'Encrypted', sub: 'On-device vault' },
          { ico: '🇮🇳', name: 'DPDP Act',  sub: 'India compliant' },
          { ico: '↩️', name: 'Revocable', sub: 'Instant, always' },
          { ico: '📅', name: 'Audited',   sub: 'Mar 24, 2026' },
        ].map(({ ico, name, sub }) => (
          <div key={name} className="trust-badge">
            <div className="trust-ico">{ico}</div>
            <div>
              <div className="trust-name">{name}</div>
              <div className="trust-sub">{sub}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AuditLogCard() {
  const { getProfile } = useApp();
  const p = getProfile();
  if (!p) return null;

  return (
    <div className="card glass">
      <div className="card-head">
        <div className="card-title">Audit Log</div>
        <div className="card-badge">{p.logs.length} entries</div>
      </div>
      <div className="alog">
        {p.logs.map((e, i) => (
          <div key={i} className="log-entry">
            <div className={`log-ico ${e.type}`}>{e.icon}</div>
            <div>
              <div className="log-action">{e.action}</div>
              <div className="log-time">{e.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
