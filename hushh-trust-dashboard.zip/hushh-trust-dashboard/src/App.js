import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import AuthScreen from './components/AuthScreen';
import Header from './components/Header';
import ScoreBand from './components/ScoreBand';
import StatsRow from './components/StatsRow';
import PermissionsCard from './components/PermissionsCard';
import DataCategoriesCard from './components/DataCategoriesCard';
import { TrustIndicatorsCard, AuditLogCard } from './components/TrustCards';
import Sidebar from './components/Sidebar';
import Toast from './components/Toast';

function Dashboard() {
  const { activeId, setActiveId, showToast } = useApp();
  const [sidebarMode, setSidebarMode] = useState(null); // null | 'permission' | 'category' | 'profile'
  const [dashKey, setDashKey] = useState(0);

  // Re-animate dashboard when profile changes
  useEffect(() => {
    setDashKey(k => k + 1);
  }, [activeId]);

  function handleLogin(id) {
    setActiveId(id);
  }

  function handleLogout() {
    if (!window.confirm('Sign out of Hushh?')) return;
    setActiveId(null);
    showToast('👋 Signed out successfully');
  }

  if (!activeId) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <>
      <div className="bg-canvas">
        <div className="orb orb1" />
        <div className="orb orb2" />
        <div className="orb orb3" />
      </div>
      <div className="grain" />

      <Header onLogout={handleLogout} onOpenSidebar={setSidebarMode} />

      <main key={dashKey}>
        <div className="hero">
          <div className="eyebrow">Privacy Control Center</div>
          <h1 className="page-title">Trust Dashboard</h1>
          <p className="page-sub">
            Complete visibility over your data. Every permission auditable. Everything revocable, instantly.
          </p>
        </div>

        <ScoreBand />
        <StatsRow />

        {/* Row 1 */}
        <div className="grid2">
          <PermissionsCard onOpenSidebar={setSidebarMode} />
          <DataCategoriesCard onOpenSidebar={setSidebarMode} />
        </div>

        {/* Row 2 */}
        <div className="grid2">
          <TrustIndicatorsCard />
          <AuditLogCard />
        </div>
      </main>

      {sidebarMode && (
        <Sidebar mode={sidebarMode} onClose={() => setSidebarMode(null)} />
      )}

      <Toast />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Dashboard />
    </AppProvider>
  );
}
