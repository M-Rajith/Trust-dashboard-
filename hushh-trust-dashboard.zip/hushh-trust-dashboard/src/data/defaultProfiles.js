const DEFAULT_PROFILES = {
  manish: {
    id: 'manish', name: 'Manish S.', emoji: '👨‍💻',
    color: 'linear-gradient(135deg,#0071e3,#004eb8)',
    password: 'manish123', score: 94, consentCount: 47,
    svcs: {
      nike:     { id: 'nike',     name: 'Nike',     emoji: '👟', bg: 'rgba(255,248,220,0.7)', scope: 'Purchase history, size preferences', on: true,  ago: '2 hrs ago' },
      spotify:  { id: 'spotify',  name: 'Spotify',  emoji: '🎵', bg: 'rgba(220,255,235,0.7)', scope: 'Music interests, listening habits',  on: true,  ago: '1 day ago' },
      coursera: { id: 'coursera', name: 'Coursera', emoji: '📚', bg: 'rgba(225,235,255,0.7)', scope: 'Browsing behavior, learning history', on: true,  ago: '3 days ago' },
      gmail:    { id: 'gmail',    name: 'Gmail',    emoji: '📧', bg: 'rgba(255,235,233,0.7)', scope: 'Email metadata (no content)',         on: false, ago: '1 week ago' },
    },
    cats: {
      shopping: { label: 'Shopping', ico: '🛍️', on: true,  pct: 72 },
      finance:  { label: 'Finance',  ico: '💳', on: true,  pct: 58 },
      browsing: { label: 'Browsing', ico: '🌐', on: true,  pct: 45 },
      health:   { label: 'Health',   ico: '💊', on: false, pct: 0  },
      location: { label: 'Location', ico: '📍', on: false, pct: 0  },
      identity: { label: 'Identity', ico: '🪪', on: false, pct: 0  },
    },
    logs: [
      { action: 'Nike read purchase_history',      type: 'new',  icon: '✅', time: 'Today · 10:42 AM' },
      { action: 'Spotify read music_interests',    type: 'read', icon: '👁️', time: 'Yesterday · 6:15 PM' },
      { action: 'You revoked Gmail location access', type: 'rev', icon: '🚫', time: 'Mar 22 · 2:30 PM' },
    ],
  },
  priya: {
    id: 'priya', name: 'Priya K.', emoji: '👩‍🎨',
    color: 'linear-gradient(135deg,#bf5af2,#7b2dcc)',
    password: 'priya123', score: 78, consentCount: 31,
    svcs: {
      instagram: { id: 'instagram', name: 'Instagram', emoji: '📸', bg: 'rgba(255,230,255,0.7)', scope: 'Interests, demographic data',   on: true,  ago: '5 hrs ago' },
      amazon:    { id: 'amazon',    name: 'Amazon',    emoji: '📦', bg: 'rgba(255,248,220,0.7)', scope: 'Purchase history, wishlist',    on: true,  ago: '2 days ago' },
      netflix:   { id: 'netflix',   name: 'Netflix',   emoji: '🎬', bg: 'rgba(255,230,230,0.7)', scope: 'Watch history, preferences',   on: false, ago: '1 week ago' },
    },
    cats: {
      shopping:      { label: 'Shopping',      ico: '🛍️', on: true,  pct: 85 },
      entertainment: { label: 'Entertainment', ico: '🎬', on: true,  pct: 65 },
      social:        { label: 'Social',        ico: '📱', on: true,  pct: 55 },
      health:        { label: 'Health',        ico: '💊', on: false, pct: 0  },
      location:      { label: 'Location',      ico: '📍', on: false, pct: 0  },
      finance:       { label: 'Finance',       ico: '💳', on: false, pct: 0  },
    },
    logs: [
      { action: 'Instagram read interests',       type: 'read', icon: '👁️', time: 'Today · 8:10 AM' },
      { action: 'Amazon read purchase_history',   type: 'read', icon: '👁️', time: 'Yesterday · 3:20 PM' },
      { action: 'You paused Netflix access',      type: 'rev',  icon: '🚫', time: 'Mar 20 · 11:00 AM' },
    ],
  },
  arjun: {
    id: 'arjun', name: 'Arjun R.', emoji: '👨‍⚕️',
    color: 'linear-gradient(135deg,#30d158,#1a7a35)',
    password: 'arjun123', score: 88, consentCount: 22,
    svcs: {
      fitbit: { id: 'fitbit', name: 'Fitbit', emoji: '⌚', bg: 'rgba(220,255,235,0.7)', scope: 'Health metrics, activity data',    on: true,  ago: '1 hr ago' },
      google: { id: 'google', name: 'Google', emoji: '🔍', bg: 'rgba(225,235,255,0.7)', scope: 'Search history, location data',   on: true,  ago: '4 hrs ago' },
      slack:  { id: 'slack',  name: 'Slack',  emoji: '💬', bg: 'rgba(225,250,255,0.7)', scope: 'Workspace activity metadata',     on: false, ago: '3 days ago' },
    },
    cats: {
      health:   { label: 'Health',   ico: '💊', on: true,  pct: 90 },
      location: { label: 'Location', ico: '📍', on: true,  pct: 40 },
      browsing: { label: 'Browsing', ico: '🌐', on: true,  pct: 30 },
      shopping: { label: 'Shopping', ico: '🛍️', on: false, pct: 0  },
      finance:  { label: 'Finance',  ico: '💳', on: false, pct: 0  },
      social:   { label: 'Social',   ico: '📱', on: false, pct: 0  },
    },
    logs: [
      { action: 'Fitbit synced health_metrics', type: 'new',  icon: '✅', time: 'Today · 9:00 AM' },
      { action: 'Google read search_history',   type: 'read', icon: '👁️', time: 'Today · 7:45 AM' },
      { action: 'You revoked Slack access',     type: 'rev',  icon: '🚫', time: 'Mar 21 · 5:00 PM' },
    ],
  },
};

export default DEFAULT_PROFILES;
