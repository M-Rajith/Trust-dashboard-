import React, { createContext, useContext, useState, useCallback, useRef } from 'react';
import DEFAULT_PROFILES from '../data/defaultProfiles';

const AppContext = createContext(null);

function loadProfiles() {
  try {
    const raw = localStorage.getItem('hushh_profiles');
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return JSON.parse(JSON.stringify(DEFAULT_PROFILES));
}

function saveProfiles(profiles) {
  try { localStorage.setItem('hushh_profiles', JSON.stringify(profiles)); } catch (e) {}
}

export function AppProvider({ children }) {
  const [profiles, setProfiles] = useState(() => loadProfiles());
  const [activeId, setActiveId] = useState(null);
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('hushh-theme') === 'dark');
  const [toastMsg, setToastMsg] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const toastTimer = useRef(null);
  const aiCache = useRef({});

  // Apply dark mode to html element
  React.useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('hushh-theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setToastVisible(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVisible(false), 3200);
  }, []);

  const getProfile = useCallback((id) => profiles[id || activeId], [profiles, activeId]);

  const updateProfiles = useCallback((updater) => {
    setProfiles(prev => {
      const next = updater(prev);
      saveProfiles(next);
      return next;
    });
  }, []);

  const updateActiveProfile = useCallback((updater) => {
    updateProfiles(prev => {
      const next = { ...prev };
      next[activeId] = updater({ ...next[activeId] });
      return next;
    });
  }, [updateProfiles, activeId]);

  const scoreLabel = (s) =>
    s >= 90 ? 'Excellent Trust Score' :
    s >= 75 ? 'Good Trust Score' :
    s >= 60 ? 'Fair Trust Score' : 'Needs Attention';

  const scoreDesc = (p) => {
    const on   = Object.values(p.svcs).filter(s => s.on).length;
    const cats = Object.values(p.cats).filter(c => c.on).length;
    return `${p.name} has ${on} active permission${on !== 1 ? 's' : ''} and ${cats} data categor${cats !== 1 ? 'ies' : 'y'} sharing. Score: ${p.score}/100.`;
  };

  const scoreOffset = (s) => Math.round(245 - (s / 100) * (245 - 24));

  const recalcScore = useCallback((profileId) => {
    const id = profileId || activeId;
    updateProfiles(prev => {
      const next = { ...prev };
      const p = { ...next[id] };
      const svcsOn = Object.values(p.svcs).filter(s => s.on).length;
      const svcsT  = Math.max(Object.keys(p.svcs).length, 1);
      const catsOn = Object.values(p.cats).filter(c => c.on).length;
      const catsT  = Math.max(Object.keys(p.cats).length, 1);
      p.score = Math.min(100, Math.max(30, Math.round(60 + (1 - svcsOn / svcsT) * 20 + (1 - catsOn / catsT) * 20)));
      next[id] = p;
      return next;
    });
  }, [activeId, updateProfiles]);

  const addLog = useCallback((action, type, icon) => {
    const t = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    updateActiveProfile(p => ({
      ...p,
      logs: [{ action, type, icon, time: `Just now · ${t}` }, ...p.logs],
    }));
  }, [updateActiveProfile]);

  const getAiSummary = useCallback(async (svcId) => {
    const key = `${activeId}_${svcId}`;
    if (aiCache.current[key]) return aiCache.current[key];
    const p = profiles[activeId];
    const s = p?.svcs[svcId];
    if (!s) return 'Service not found.';
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 120,
          messages: [{
            role: 'user',
            content: `You are the Hushh privacy AI. Write a 2-sentence plain-English trust summary.\nService: ${s.name}\nData: ${s.scope}\nStatus: ${s.on ? 'active' : 'paused'}\nUnder 40 words, reassuring. End with "You can revoke this anytime."`,
          }],
        }),
      });
      const d = await res.json();
      const text = d.content?.[0]?.text || aiFallback(s);
      aiCache.current[key] = text;
      return text;
    } catch (e) {
      const fb = aiFallback(s);
      aiCache.current[key] = fb;
      return fb;
    }
  }, [activeId, profiles]);

  function aiFallback(s) {
    return `${s.name} has ${s.on ? 'read-only' : 'paused'} access to your ${s.scope.toLowerCase()}. No additional data is accessed beyond what you approved. You can revoke this anytime.`;
  }

  return (
    <AppContext.Provider value={{
      profiles, activeId, setActiveId,
      darkMode, setDarkMode,
      toastMsg, toastVisible, showToast,
      getProfile, updateProfiles, updateActiveProfile,
      scoreLabel, scoreDesc, scoreOffset,
      recalcScore, addLog, getAiSummary,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
